module.exports = {
    HOST: "localhost",
    USER: "root", //mysql username
    PASSWORD: "root", //mysql password
    DB: "web" //database name
};

